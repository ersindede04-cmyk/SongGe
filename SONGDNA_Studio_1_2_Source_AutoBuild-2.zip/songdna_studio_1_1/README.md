# SONGDNA Studio 1.2

SONGDNA Studio 1.2 is an Android WebView app and mobile web interface for designing Suno-ready music packages. It retains the 18 Music DNA presets and adds an optional server-backed AI lyric engine.

## What's new in 1.2
- OpenAI/ChatGPT and Google Gemini provider support through a private server.
- Full lyric-generation prompt uses DNA, fusion, BPM, language, vocal setup, cultural pre-intro, local phrases and creative notes.
- AI-generated lyrics are inserted into the Suno Lyrics output; no placeholder template is passed off as finished lyrics.
- Restored local cultural phrase and extra creative-direction fields.
- Exclude Styles is a separate output tab, not appended to Style.
- Style output is capped at 1,000 characters.
- Server-side provider keys; keys are never entered into or stored by the Android app.
- Rate limiting, optional app access token, request-size validation and health endpoint.
- Android Internet permission added for HTTPS API requests.

## Important: AI needs a hosted backend
The source package includes `backend/server.js`, a Node.js backend with no third-party npm dependencies. It calls OpenAI or Gemini from the server, so you must deploy it to a host that supports Node.js and HTTPS.

1. Deploy the `backend` folder to a Node.js host.
2. Configure environment variables from `backend/.env.example`.
3. Add `OPENAI_API_KEY` and/or `GEMINI_API_KEY` in the host's secret/environment settings. Do not place provider keys in the app.
4. Set `ALLOWED_ORIGIN` to the origin serving the app. For initial tests, `*` is supported; restrict it for production.
5. Optional: set `APP_ACCESS_TOKEN` on the server, then enter the same value in the app's "Uygulama erişim kodu" field.
6. Open the backend's `/health` endpoint. It reports whether provider keys are configured (never returns the keys).
7. In SONGDNA Studio, enter the backend HTTPS base URL, select OpenAI or Gemini, and tap "Yapay zekâ ile şarkı sözü üret".

### Local backend test
```bash
cd backend
cp .env.example .env
# Set OPENAI_API_KEY or GEMINI_API_KEY in your shell environment.
node server.js
```
Then use `http://localhost:8080` only for local browser testing. Android production builds require an HTTPS backend because cleartext traffic is disabled.

## APK build
GitHub Actions workflow: `.github/workflows/build-apk.yml`
- Push the repository to GitHub.
- Open Actions > Build APK > Run workflow.
- Download the `SONGDNA-debug-apk` artifact.

## Limitations / verification
- This environment cannot run an Android SDK build or deploy a public backend. The APK and live AI calls have not been tested here.
- JavaScript syntax and backend syntax are checked separately, but this does not replace device testing.
- OpenAI and Gemini API access is billed separately by their providers. A ChatGPT subscription does not automatically include API credits.
