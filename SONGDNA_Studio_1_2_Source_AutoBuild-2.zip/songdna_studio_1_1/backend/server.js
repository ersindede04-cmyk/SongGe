const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
// Minimal .env loader (keeps deployment dependency-free).
try {
  const envFile = fs.readFileSync(path.join(__dirname, ".env"), "utf8");
  for (const line of envFile.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (match && process.env[match[1]] === undefined) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, "");
  }
} catch (_) {}

const PORT = Number(process.env.PORT || 8080);
const APP_ACCESS_TOKEN = process.env.APP_ACCESS_TOKEN || "";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || "*";
const WINDOW_MS = 60_000, MAX_REQUESTS = 12, MAX_BODY = 40_000;
const buckets = new Map();

function send(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
    "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-App-Token",
    "Cache-Control": "no-store"
  });
  res.end(body);
}
function rateLimited(ip) {
  const now = Date.now(), old = buckets.get(ip) || [];
  const recent = old.filter(t => now - t < WINDOW_MS);
  if (recent.length >= MAX_REQUESTS) return true;
  recent.push(now); buckets.set(ip, recent); return false;
}
async function readBody(req) {
  let body = "";
  for await (const chunk of req) {
    body += chunk;
    if (body.length > MAX_BODY) throw new Error("İstek çok büyük.");
  }
  return JSON.parse(body || "{}");
}
async function openai(prompt, model) {
  if (!OPENAI_API_KEY) throw new Error("Sunucuda OPENAI_API_KEY tanımlı değil.");
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Authorization": `Bearer ${OPENAI_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: model || OPENAI_MODEL,
      temperature: 0.85,
      messages: [
        { role: "system", content: "You are a professional songwriter. Follow the user's creative brief exactly. Return only a short TITLE line and complete original song lyrics. Never return placeholders or instructions." },
        { role: "user", content: prompt }
      ]
    })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `OpenAI isteği başarısız (${response.status}).`);
  return data.choices?.[0]?.message?.content || "";
}
async function gemini(prompt, model) {
  if (!GEMINI_API_KEY) throw new Error("Sunucuda GEMINI_API_KEY tanımlı değil.");
  const selected = model || GEMINI_MODEL;
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(selected)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: "You are a professional songwriter. Follow the user's creative brief exactly. Return only a short TITLE line and complete original song lyrics. Never return placeholders or instructions." }] },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.85 }
    })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `Gemini isteği başarısız (${response.status}).`);
  return (data.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("\n");
}
const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
      "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-App-Token",
      "Access-Control-Max-Age": "86400"
    }); return res.end();
  }
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (req.method === "GET" && url.pathname === "/health") return send(res, 200, { ok: true, service: "SONGDNA AI", providers: { openai: !!OPENAI_API_KEY, gemini: !!GEMINI_API_KEY } });
  if (req.method !== "POST" || url.pathname !== "/api/lyrics") return send(res, 404, { error: "Endpoint bulunamadı." });
  if (rateLimited(req.socket.remoteAddress || "unknown")) return send(res, 429, { error: "Çok fazla istek. Bir dakika sonra tekrar dene." });
  if (APP_ACCESS_TOKEN && req.headers["x-app-token"] !== APP_ACCESS_TOKEN) return send(res, 401, { error: "Uygulama erişim kodu geçersiz." });
  try {
    const input = await readBody(req);
    const prompt = typeof input.prompt === "string" ? input.prompt.trim() : "";
    if (!prompt || prompt.length > 20_000) return send(res, 400, { error: "Geçerli bir söz üretim istemi gerekli (en fazla 20.000 karakter)." });
    const provider = input.provider === "gemini" ? "gemini" : "openai";
    const lyrics = provider === "gemini" ? await gemini(prompt, input.model) : await openai(prompt, input.model);
    if (!lyrics.trim()) return send(res, 502, { error: "Yapay zekâ boş yanıt verdi." });
    return send(res, 200, { provider, model: input.model || (provider === "gemini" ? GEMINI_MODEL : OPENAI_MODEL), lyrics });
  } catch (error) {
    console.error(error);
    return send(res, 500, { error: error.message || "Beklenmeyen sunucu hatası." });
  }
});
server.listen(PORT, "0.0.0.0", () => console.log(`SONGDNA AI server listening on ${PORT}`));
