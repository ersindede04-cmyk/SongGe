# SONGDNA Studio 1.8 — Clean Build Developer Edition

Bu paket, GitHub deposunun **ana dizinine doğrudan yerleştirilecek** şekilde hazırlanmıştır. ZIP açıldığında ayrıca bir proje klasörünün içine girmeniz gerekmez.

## Hızlı kurulum (telefon veya bilgisayar)
1. Bu ZIP'i indirin ve cihazınızda çıkartın.
2. Çıkan klasörün içindeki tüm dosya ve klasörleri GitHub deposunun ana dizinine yükleyin.
3. Gizli `.github` klasörünün yüklendiğini doğrulayın.
4. GitHub'da `Actions` sekmesini açın.
5. `SONGDNA Studio 1.8 - Android APK` iş akışını seçin.
6. `Run workflow` düğmesine basın.
7. İşlem yeşil tik ile bittiğinde çalıştırmayı açın ve `SONGDNA-Studio-1.8-debug-APK` artifact'ini indirin.
8. Artifact ZIP'ini çıkartın. İçindeki `app-debug.apk` Android kurulum dosyasıdır.

## Çok önemli
- ZIP dosyasını GitHub'a tek bir dosya olarak yüklemeyin.
- Projeyi ikinci bir klasörün içine koymayın.
- `.github/workflows/build-apk.yml` dosyasını elle yeniden yazmayın.
- Başka depodaki eski `Build APK` workflow'unu çalıştırmayın. Bu paket tek bir yeni workflow içerir.
- Bu sürümün workflow'u yalnızca `workflow_dispatch` ile elle başlatılır; her dosya yüklemesinde gereksiz yere derleme başlatmaz.

## Depo ana dizini
```text
.github/
  workflows/
    build-apk.yml
android-wrapper/
  app/
backend/
www/
scripts/
  verify-source.py
README.md
GITHUB_KURULUM_TR.md
```

## Derleme ortamı
- Java 17 (Temurin)
- Gradle 8.9
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Android Gradle Plugin 8.7.3
- Kotlin Android Plugin 2.0.21
- Android minSdk 23, targetSdk 35
- App versionName 1.8, versionCode 7

## Paket neleri koruyor?
- 18 Music DNA paketi ve mevcut yaratıcı kontroller
- Önceki bölgesel otomatik intro akışı
- Intro DNA 14–33 seçilebilir paketleri
- Türkçe uygulama arayüzü
- Suno için İngilizce bölüm/vokal etiketleri
- PRESERVE kısa/kapalı/uzun seçenekleri
- LYRICS, STYLE, EXCLUDE ve söz üretim akışları
- Backend kaynak kodu ve sunucu tarafında API anahtarı yaklaşımı

**Kaynak notu:** Sağlanan 1.7 kaynak paketinde 1–13 numaralı intro metinleri ayrı ayrı kayıtlı değildi; eski bölgesel otomatik intro davranışı korundu. Eksik özgün metinler uydurulmadı.

## Backend
Android APK derlemesi için backend'i internete açmak veya API anahtarı eklemek gerekmez. AI servislerini kullanmak için `backend/` klasörünü Node.js 18+ destekleyen HTTPS bir sunucuya dağıtın ve `.env.example` içindeki ayarları sunucunun ortam değişkenleri olarak tanımlayın. API anahtarlarını Android uygulamasına veya GitHub deposuna koymayın.

## Doğrulama sınırı
Bu paketteki kaynak ve dizin kontrolleri GitHub Actions içinde derlemeden önce çalıştırılır. **APK'nın gerçekten üretildiği ancak GitHub Actions yeşil tik verdiğinde ve artifact indirilebildiğinde doğrulanmış olur.** Telefon kurulumu ve çalışma testi ayrıca yapılmalıdır.
