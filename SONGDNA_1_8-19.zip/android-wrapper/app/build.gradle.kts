plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.songdna.studio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.songdna.studio"
        minSdk = 23
        targetSdk = 35
        versionCode = 7
        versionName = "1.8"
    }
}
