#!/usr/bin/env python3
"""Deterministic pre-build checks for the SONGDNA Studio 1.8 repository."""
from pathlib import Path
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

REQUIRED = [
    ".github/workflows/build-apk.yml",
    "android-wrapper/settings.gradle.kts",
    "android-wrapper/build.gradle.kts",
    "android-wrapper/gradle.properties",
    "android-wrapper/app/build.gradle.kts",
    "android-wrapper/app/src/main/AndroidManifest.xml",
    "android-wrapper/app/src/main/java/com/songdna/studio/MainActivity.kt",
    "android-wrapper/app/src/main/assets/www/index.html",
    "www/index.html",
    "backend/server.js",
    "backend/package.json",
    "backend/.env.example",
]
missing = [item for item in REQUIRED if not (ROOT / item).is_file()]
if missing:
    raise SystemExit("FAIL: Required repository files are missing:\n- " + "\n- ".join(missing))
print("PASS: Required project files and repository-root layout.")

# Ensure web and Android ship the exact same UI source.
web_path = ROOT / "www/index.html"
android_web_path = ROOT / "android-wrapper/app/src/main/assets/www/index.html"
web = web_path.read_text(encoding="utf-8")
android_web = android_web_path.read_text(encoding="utf-8")
if web != android_web:
    raise SystemExit("FAIL: www/index.html differs from Android's bundled WebView asset.")
print("PASS: Web and Android UI assets are byte-for-byte identical.")

# Parse all Android XML resources and manifest.
xml_files = list((ROOT / "android-wrapper/app/src/main").rglob("*.xml"))
for xml_file in xml_files:
    ET.parse(xml_file)
print(f"PASS: {len(xml_files)} Android XML file(s) parse.")

# Validate Gradle project configuration and version.
settings = (ROOT / "android-wrapper/settings.gradle.kts").read_text(encoding="utf-8")
root_gradle = (ROOT / "android-wrapper/build.gradle.kts").read_text(encoding="utf-8")
app_gradle = (ROOT / "android-wrapper/app/build.gradle.kts").read_text(encoding="utf-8")
if 'include(":app")' not in settings:
    raise SystemExit('FAIL: Android settings.gradle.kts does not include the :app module.')
if 'id("com.android.application") version "8.7.3" apply false' not in root_gradle:
    raise SystemExit("FAIL: Android Gradle Plugin version is not the expected 8.7.3.")
if "compileSdk = 35" not in app_gradle or 'versionName = "1.8"' not in app_gradle:
    raise SystemExit("FAIL: Android compile SDK or app version is inconsistent.")
print("PASS: Android Gradle module, plugin and version configuration.")

# Validate backend package metadata without installing packages or exposing secrets.
package = json.loads((ROOT / "backend/package.json").read_text(encoding="utf-8"))
if not package.get("scripts", {}).get("start"):
    raise SystemExit("FAIL: backend/package.json is missing its start script.")
print("PASS: Backend package metadata.")

# Syntax-check inline JavaScript and backend JavaScript.
node = shutil_which = __import__("shutil").which("node")
if not node:
    raise SystemExit("FAIL: Node.js is required for JavaScript syntax checks.")
blocks = re.findall(r"<script(?:\s[^>]*)?>(.*?)</script\s*>", web, re.S | re.I)
if not blocks:
    raise SystemExit("FAIL: No inline JavaScript blocks found in www/index.html.")
for number, block in enumerate(blocks, 1):
    result = subprocess.run([node, "--check", "--input-type=commonjs"],
                            input=block, text=True, capture_output=True)
    if result.returncode:
        raise SystemExit(f"FAIL: Inline JavaScript block {number}:\n{result.stderr}")
server_check = subprocess.run([node, "--check", str(ROOT / "backend/server.js")],
                              text=True, capture_output=True)
if server_check.returncode:
    raise SystemExit("FAIL: backend/server.js syntax:\n" + server_check.stderr)
print(f"PASS: {len(blocks)} inline JavaScript block(s) and backend/server.js syntax.")

# Confirm all added regional presets remain selectable; legacy 1–13 are a regional auto-flow,
# not 13 separately authored records in the supplied source.
preset_ids = [int(value) for value in re.findall(r"^\s*(\d+):\{region:", web, re.M)]
if preset_ids != list(range(14, 34)):
    raise SystemExit(f"FAIL: Expected selectable Intro DNA IDs 14–33; found {preset_ids}.")
if "introPack" not in web or "PRESERVE" not in web.upper():
    raise SystemExit("FAIL: Intro DNA selector or PRESERVE controls are missing.")
print("PASS: Intro DNA presets 14–33 and PRESERVE controls.")

# Confirm the workflow builds from repository root and does not unzip a nested source ZIP.
workflow = (ROOT / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")
if "unzip " in workflow.lower():
    raise SystemExit("FAIL: Workflow unexpectedly contains a nested ZIP extraction step.")
if "-p android-wrapper" not in workflow:
    raise SystemExit("FAIL: Workflow Gradle project path is not repository-root relative.")
if "android-35" not in workflow or "build-tools;35.0.0" not in workflow:
    raise SystemExit("FAIL: Required Android SDK components are not installed by workflow.")
if "actions/upload-artifact@v4" not in workflow:
    raise SystemExit("FAIL: Workflow does not upload the APK artifact.")
print("PASS: GitHub Actions workflow paths, SDK setup and artifact output.")

print("ALL PRE-BUILD CHECKS PASSED.")
print("Remote Android compilation and physical-device testing must still be completed in GitHub/Android.")
